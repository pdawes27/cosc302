// Challenge 08: sequence alignment

int main(int argc, char *argv[]) {
    return 0;
}


