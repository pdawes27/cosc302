#include "disjoint.h"
#include <iostream>

using namespace std;

int main() {

  cout << "This program doesn't do anything yet.\n";
  return 0;

}
