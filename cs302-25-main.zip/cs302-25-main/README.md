# cs302-25
Advanced data structures and algorithms (CS302 @UTK)

Scott J Emrich; University of Tennessee - Knoxville

Note these files are a mix of a former class of this instructor at University of Notre Dame and a former class with the same course objectives taught by Dr. Plank as recently as Spring 2023. Not all of these files are guaranteed to be the same as the previous iteration of this course by Dr. Emrich (e.g., fall of 2024).
