// Challenge 5: Minimum Spanning Tree

using namespace std;

// Main Execution

int main(int argc, char *argv[]) {

  return (0);

}

