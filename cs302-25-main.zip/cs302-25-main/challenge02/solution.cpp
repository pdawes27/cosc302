// Challenge 02: Closest Numbers
// Name:  xxxxx

// Brief description:

// This code solves yyyy based on the following idea/implementation...

#include <algorithm>
#include <climits>
#include <cstdlib>
#include <iostream>
#include <vector>

using namespace std;

// Main Execution

int main(int argc, char *argv[]) {
    return EXIT_SUCCESS;
}
