// qsort.cpp

#include "volsort.h"

#include <cstdlib>
#include <array>
#include <iostream>

void qsort_sort(List &l, bool numeric) {

}

