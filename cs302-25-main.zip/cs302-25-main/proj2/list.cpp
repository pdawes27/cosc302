#include "volsort.h"


List::List() {


}

List::~List() {

}

void List::push_front(const std::string &s) {
 
}
