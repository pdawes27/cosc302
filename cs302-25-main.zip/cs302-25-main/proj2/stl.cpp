// stl.cpp

#include "volsort.h"

#include <algorithm>
#include <iostream>

void stl_sort(List &l, bool numeric) {
}

