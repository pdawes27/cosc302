// quick.cpp

#include "volsort.h"

#include <iostream>

// Prototypes

Node *qsort(Node *head, bool numeric);
void  partition(Node *head, Node *pivot, Node *&left, Node *&right, bool numeric);
Node *concatenate(Node *left, Node *right);

// Implementations

void quick_sort(List &l, bool numeric) {
}

Node *qsort(Node *head, bool numeric) {
}

void partition(Node *head, Node *pivot, Node *&left, Node *&right, bool numeric) {
}

Node *concatenate(Node *left, Node *right) {
}

