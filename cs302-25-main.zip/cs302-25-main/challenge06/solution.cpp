// Challenge 06: Repeated DNA sequences

int main(int argc, char *argv[]) {
    return 0;
}


